export * from './Heading';
